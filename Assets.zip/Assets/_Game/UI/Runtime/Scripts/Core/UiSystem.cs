﻿using SeasonalBastion.UI.Input;
using SeasonalBastion.UI.Navigation;
using SeasonalBastion.UI.Overlay;
using SeasonalBastion.UI.Presenters;
using SeasonalBastion.UI.Services;
using UnityEngine;
using UnityEngine.UIElements;

namespace SeasonalBastion.UI
{
    /// <summary>
    /// Orchestrator: bind presenters, manage registries, tick overlay, update input gate.
    /// </summary>
    public sealed class UiSystem : MonoBehaviour
    {
        public UIContext Ctx { get; private set; }

        public IInputGate InputGate => Ctx?.InputGate;

        private UIDocument _hud;
        private UIDocument _panels;
        private UIDocument _modals;
        private UIDocument _overlay;

        private IUiPauseController _pauseController;

        private UiHitTest _hitTest;
        private InputGate _gate;
        private UIStateStore _store;

        private PanelRegistry _panelRegistry;
        private ModalStackController _modalStack;

        private ToastController _toasts;
        private TooltipController _tooltips;

        // Presenters (ví dụ)
        private HudPresenter _hudPresenter;
        private BuildPanelPresenter _buildPresenter;
        private InspectPanelPresenter _inspectPresenter;
        private SettingsModalPresenter _settingsModal;
        private ConfirmModalPresenter _confirmModal;

        private bool _initialized;

        public void Initialize(
            UIDocument hud,
            UIDocument panels,
            UIDocument modals,
            UIDocument overlay,
            object services,
            IUiPauseController pauseController)
        {
            if (_initialized) return;
            _initialized = true;

            _hud = hud;
            _panels = panels;
            _modals = modals;
            _overlay = overlay;

            _pauseController = pauseController;

            _store = new UIStateStore();

            _gate = new InputGate(_store);
            _hitTest = new UiHitTest(_gate);

            _panelRegistry = new PanelRegistry(_store);
            _modalStack = new ModalStackController(_store, _pauseController);

            _toasts = new ToastController();
            _tooltips = new TooltipController();

            Ctx = new UIContext(
                services,
                _store,
                _gate,
                _panelRegistry,
                _modalStack,
                _toasts,
                _tooltips,
                _hud,
                _panels,
                _modals,
                _overlay
            );

            BindTopologyAndPresenters();
            WireBasicFlow();
        }

        private void BindTopologyAndPresenters()
        {
            var hudRoot = _hud ? _hud.rootVisualElement : null;
            var panelsRoot = _panels ? _panels.rootVisualElement : null;
            var modalsRoot = _modals ? _modals.rootVisualElement : null;
            var overlayRoot = _overlay ? _overlay.rootVisualElement : null;

            // Ensure base hosts exist (fallback nếu UXML thiếu)
            var leftDock = UiElementUtil.GetOrCreateChild(panelsRoot, "LeftDockHost");
            var rightDock = UiElementUtil.GetOrCreateChild(panelsRoot, "RightDockHost");

            var scrim = UiElementUtil.GetOrCreateChild(modalsRoot, "Scrim");
            var modalHost = UiElementUtil.GetOrCreateChild(modalsRoot, "ModalHost");

            var toastHost = UiElementUtil.GetOrCreateChild(overlayRoot, "ToastHost");
            var tooltipHost = UiElementUtil.GetOrCreateChild(overlayRoot, "TooltipHost");

            // Mark blockers by default (bạn có thể chuyển sang USS/UXML set class)
            leftDock?.AddToClassList(UiKeys.Class_BlockWorld);
            rightDock?.AddToClassList(UiKeys.Class_BlockWorld);
            scrim?.AddToClassList(UiKeys.Class_BlockWorld);

            // Init controllers hosts
            _modalStack.Bind(modalsRoot, scrim, modalHost);
            _toasts.Bind(toastHost);
            _tooltips.Bind(tooltipHost);

            // Register documents for hit test (order from topmost to bottom)
            _hitTest.SetDocuments(_overlay, _modals, _panels, _hud);

            // Create presenters
            _hudPresenter = new HudPresenter();
            _buildPresenter = new BuildPanelPresenter();
            _inspectPresenter = new InspectPanelPresenter();
            _settingsModal = new SettingsModalPresenter();
            _confirmModal = new ConfirmModalPresenter();

            // Bind presenters to their roots/templates
            _hudPresenter.Bind(Ctx, hudRoot);

            // Panels: create containers (in real project, you should instantiate from UXML templates)
            var buildRoot = UiElementUtil.GetOrCreateChild(leftDock, "BuildPanel");
            var inspectRoot = UiElementUtil.GetOrCreateChild(rightDock, "InspectPanel");

            _buildPresenter.Bind(Ctx, buildRoot);
            _inspectPresenter.Bind(Ctx, inspectRoot);

            _panelRegistry.Register(UiKeys.Panel_Build, _buildPresenter, buildRoot);
            _panelRegistry.Register(UiKeys.Panel_Inspect, _inspectPresenter, inspectRoot);

            // Modals: modal content containers
            var settingsRoot = UiElementUtil.GetOrCreateChild(modalHost, "SettingsModal");
            var confirmRoot = UiElementUtil.GetOrCreateChild(modalHost, "ConfirmModal");

            _settingsModal.Bind(Ctx, settingsRoot);
            _confirmModal.Bind(Ctx, confirmRoot);

            _modalStack.Register(UiKeys.Modal_Settings, _settingsModal, settingsRoot);
            _modalStack.Register(UiKeys.Modal_Confirm, _confirmModal, confirmRoot);

            // Default visibility
            UiElementUtil.SetVisible(buildRoot, false);
            UiElementUtil.SetVisible(inspectRoot, false);
            UiElementUtil.SetVisible(settingsRoot, false);
            UiElementUtil.SetVisible(confirmRoot, false);
        }

        private void WireBasicFlow()
        {
            // When selection changes -> open Inspect panel (demo)
            _store.SelectionChanged += id =>
            {
                if (id >= 0) _panelRegistry.Show(UiKeys.Panel_Inspect);
                else _panelRegistry.HideCurrent();
            };

            // When modal stack changes -> ensure top modal is visible
            _store.ModalStackChanged += _ =>
            {
                // handled by ModalStackController internals
            };

            // Example: show Build panel at start if needed
            // _panelRegistry.Show(UiKeys.Panel_Build);
        }

        private void Update()
        {
            if (!_initialized) return;

            _hitTest.UpdatePointerBlocking();
            _toasts.Tick(Time.unscaledDeltaTime);
            _tooltips.Tick(Time.unscaledDeltaTime);
        }

        private void OnDestroy()
        {
            if (!_initialized) return;

            _hudPresenter?.Unbind();
            _buildPresenter?.Unbind();
            _inspectPresenter?.Unbind();
            _settingsModal?.Unbind();
            _confirmModal?.Unbind();

            _store?.ClearModals();
        }
    }
}