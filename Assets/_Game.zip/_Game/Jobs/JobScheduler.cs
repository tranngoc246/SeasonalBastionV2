using System;
using System.Collections.Generic;
using SeasonalBastion.Contracts;

namespace SeasonalBastion
{
    public sealed class JobScheduler : IJobScheduler, ITickable
    {
        private readonly IWorldState _w;
        private readonly IJobBoard _board;
        private readonly IClaimService _claims;
        private readonly JobExecutorRegistry _exec;
        private readonly IEventBus _bus;
        private readonly IDataRegistry _data;
        private readonly INotificationService _noti;

        public int AssignedThisTick { get; private set; }

        // Reuse buffers (avoid per-tick GC)
        private readonly List<NpcId> _npcIds = new(64);
        private readonly List<BuildingId> _buildingIds = new(128);
        private readonly HashSet<int> _workplacesWithNpc = new();

        // Prevent enqueue spam
        private readonly Dictionary<int, JobId> _harvestJobByWorkplace = new();
        private readonly Dictionary<int, JobId> _haulJobByWorkplaceAndType = new(); // key = workplace*16 + type

        // No-job notifications (throttle per workplace)
        private readonly Dictionary<int, float> _noJobNextNotifyAt = new();

        private float _claimCleanupTimer;

        public JobScheduler(
            IWorldState w,
            IJobBoard board,
            IClaimService claims,
            JobExecutorRegistry exec,
            IEventBus bus,
            IDataRegistry data,
            INotificationService noti)
        {
            _w = w;
            _board = board;
            _claims = claims;
            _exec = exec;
            _bus = bus;
            _data = data;
            _noti = noti;
        }

        public void Tick(float dt)
        {
            AssignedThisTick = 0;

            BuildSortedNpcIds();
            BuildSortedBuildingIds();
            BuildWorkplaceHasNpcSet();

            // 0) Ensure jobs exist (Harvest + HaulBasic)
            EnqueueHarvestJobsIfNeeded();
            EnqueueHaulJobsIfNeeded();

            // 1) Assign jobs to idle NPCs (deterministic)
            for (int i = 0; i < _npcIds.Count; i++)
            {
                var nid = _npcIds[i];
                if (!_w.Npcs.Exists(nid)) continue;

                var ns = _w.Npcs.Get(nid);

                if (!ns.IsIdle || ns.CurrentJob.Value != 0) { _w.Npcs.Set(nid, ns); continue; }
                if (ns.Workplace.Value == 0) { _w.Npcs.Set(nid, ns); continue; }

                if (TryAssignInternal(nid, ref ns))
                    AssignedThisTick++;

                _w.Npcs.Set(nid, ns);
            }

            // 2) Tick current jobs (deterministic)
            for (int i = 0; i < _npcIds.Count; i++)
            {
                var nid = _npcIds[i];
                if (!_w.Npcs.Exists(nid)) continue;

                var ns = _w.Npcs.Get(nid);
                if (ns.CurrentJob.Value == 0) { _w.Npcs.Set(nid, ns); continue; }

                if (!_board.TryGet(ns.CurrentJob, out var job))
                {
                    CleanupNpcJob(nid, ref ns);
                    _w.Npcs.Set(nid, ns);
                    continue;
                }

                var executor = _exec.Get(job.Archetype);
                executor.Tick(nid, ref ns, ref job, dt);

                _board.Update(job);

                if (IsTerminal(job.Status))
                    CleanupNpcJob(nid, ref ns);

                _w.Npcs.Set(nid, ns);
            }

            // Periodic cleanup to prevent orphan claims if NPCs are removed/reset.
            _claimCleanupTimer += dt;
            if (_claimCleanupTimer >= 2f)
            {
                _claimCleanupTimer = 0f;
                _claims?.CleanupInvalidOwners(_w.Npcs);
            }
        }

        public bool TryAssign(NpcId npc, out Job assigned)
        {
            assigned = default;
            if (!_w.Npcs.Exists(npc)) return false;

            var ns = _w.Npcs.Get(npc);
            if (!ns.IsIdle || ns.CurrentJob.Value != 0) return false;
            if (ns.Workplace.Value == 0) return false;

            if (!TryAssignInternal(npc, ref ns)) return false;
            _w.Npcs.Set(npc, ns);

            return _board.TryGet(ns.CurrentJob, out assigned);
        }

        private bool TryAssignInternal(NpcId npc, ref NpcState ns)
        {
            if (!_w.Buildings.Exists(ns.Workplace)) return false;

            var wps = _w.Buildings.Get(ns.Workplace);
            var allowed = GetWorkplaceAllowedRoles(wps.DefId);
            if (allowed == WorkRoleFlags.None)
            {
                NotifyNoJobs(ns.Workplace, wps.DefId);
                return false;
            }

            // Day13: only pull jobs allowed by workplace roles
            Job peek;
            if (_board is JobBoard jb)
            {
                if (!jb.TryPeekForWorkplaceFiltered(ns.Workplace, allowed, out peek))
                {
                    NotifyNoJobs(ns.Workplace, wps.DefId);
                    return false;
                }
            }
            else
            {
                if (!_board.TryPeekForWorkplace(ns.Workplace, out peek))
                {
                    NotifyNoJobs(ns.Workplace, wps.DefId);
                    return false;
                }

                if (!IsJobAllowed(allowed, peek.Archetype))
                {
                    NotifyNoJobs(ns.Workplace, wps.DefId);
                    return false;
                }
            }

            // Preflight for HaulBasic (NEW): only claim if any harvest producer has something in LOCAL storage.
            if (peek.Archetype == JobArchetype.HaulBasic && !AnyHarvestProducerHasAmount(peek.ResourceType))
                return false;

            if (!_board.TryClaim(peek.Id, npc))
                return false;

            // Refresh job after claim (board updated internal copy)
            if (!_board.TryGet(peek.Id, out var job))
                return false;

            job.Status = JobStatus.InProgress;
            job.ClaimedBy = npc;
            _board.Update(job);

            ns.CurrentJob = job.Id;
            ns.IsIdle = false;
            return true;
        }

        private WorkRoleFlags GetWorkplaceAllowedRoles(string defId)
        {
            if (_data == null || string.IsNullOrEmpty(defId)) return WorkRoleFlags.None;
            try
            {
                return _data.GetBuilding(defId).WorkRoles;
            }
            catch
            {
                // Missing def => treat as no roles (fail-safe)
                return WorkRoleFlags.None;
            }
        }

        private bool HasWorkRole(string defId, WorkRoleFlags required)
        {
            var roles = GetWorkplaceAllowedRoles(defId);
            return (roles & required) != 0;
        }

        private static bool IsJobAllowed(WorkRoleFlags allowed, JobArchetype archetype)
        {
            return archetype switch
            {
                JobArchetype.Harvest => (allowed & WorkRoleFlags.Harvest) != 0,
                JobArchetype.HaulBasic => (allowed & WorkRoleFlags.HaulBasic) != 0,
                JobArchetype.HaulToForge => (allowed & (WorkRoleFlags.HaulBasic | WorkRoleFlags.Armory)) != 0,
                JobArchetype.BuildDeliver or JobArchetype.BuildWork => (allowed & WorkRoleFlags.Build) != 0,
                JobArchetype.CraftAmmo => (allowed & WorkRoleFlags.Craft) != 0,
                JobArchetype.ResupplyTower => (allowed & WorkRoleFlags.Armory) != 0,
                _ => true,
            };
        }

        private void NotifyNoJobs(BuildingId workplace, string workplaceDefId)
        {
            if (_noti == null) return;

            // Per-workplace throttle (plus NotificationService built-in cooldown by key)
            float now = UnityEngine.Time.realtimeSinceStartup;
            if (_noJobNextNotifyAt.TryGetValue(workplace.Value, out var next) && now < next)
                return;

            _noJobNextNotifyAt[workplace.Value] = now + 3f; // matches default cooldown

            _noti.Push(
                key: $"NoJobs_{workplace.Value}",
                title: "NPC không có việc để làm",
                body: $"Workplace={workplaceDefId} (#{workplace.Value}) không có job hợp lệ.",
                severity: NotificationSeverity.Info,
                payload: new NotificationPayload(workplace, default, "no_jobs"),
                cooldownSeconds: 3f,
                dedupeByKey: true);
        }

        private void CleanupNpcJob(NpcId npc, ref NpcState ns)
        {
            ns.CurrentJob = default;
            ns.IsIdle = true;
            _claims.ReleaseAll(npc); // safest against claim leak
        }

        // -------------------------
        // Enqueue logic (Day 12)
        // -------------------------

        private void EnqueueHarvestJobsIfNeeded()
        {
            for (int i = 0; i < _buildingIds.Count; i++)
            {
                var bid = _buildingIds[i];
                if (!_w.Buildings.Exists(bid)) continue;

                var bs = _w.Buildings.Get(bid);
                if (!bs.IsConstructed) continue;

                // Day13: harvest only if workplace roles allow it
                if (!HasWorkRole(bs.DefId, WorkRoleFlags.Harvest)) continue;

                // only if there is at least 1 NPC assigned to this workplace
                if (!_workplacesWithNpc.Contains(bid.Value)) continue;

                // 1 pending job per workplace
                if (_harvestJobByWorkplace.TryGetValue(bid.Value, out var oldId))
                {
                    if (_board.TryGet(oldId, out var old) && !IsTerminal(old.Status))
                        continue;
                }

                // Only enqueue if local not full (LOCKED caps)
                var rt = HarvestResourceType(bs.DefId);
                int cap = HarvestLocalCap(bs.DefId, NormalizeLevel(bs.Level));
                int cur = GetAmountFromBuilding(bs, rt);
                if (cap > 0 && cur >= cap) continue;

                var zoneCell = _w.Zones.PickCell(rt, bs.Anchor);

                // If zone resolves to default, skip enqueue to avoid NPCs marching to (0,0).
                if (zoneCell.X == 0 && zoneCell.Y == 0)
                    continue;

                var j = new Job
                {
                    Archetype = JobArchetype.Harvest,
                    Status = JobStatus.Created,
                    Workplace = bid,
                    SourceBuilding = bid,
                    DestBuilding = default,
                    Site = default,
                    Tower = default,
                    ResourceType = rt,
                    Amount = 0,
                    TargetCell = zoneCell,
                    CreatedAt = 0
                };

                var newId = _board.Enqueue(j);
                _harvestJobByWorkplace[bid.Value] = newId;
            }
        }

        private void EnqueueHaulJobsIfNeeded()
        {
            // Enqueue hauling jobs for Warehouse/HQ workplaces with at least one NPC.
            for (int i = 0; i < _buildingIds.Count; i++)
            {
                var wid = _buildingIds[i];
                if (!_w.Buildings.Exists(wid)) continue;

                var bs = _w.Buildings.Get(wid);
                if (!bs.IsConstructed) continue;
                if (!HasWorkRole(bs.DefId, WorkRoleFlags.HaulBasic)) continue;
                if (!_workplacesWithNpc.Contains(wid.Value)) continue;

                TryEnsureHaulJob(wid, bs, ResourceType.Wood);
                TryEnsureHaulJob(wid, bs, ResourceType.Food);
                TryEnsureHaulJob(wid, bs, ResourceType.Stone);
                TryEnsureHaulJob(wid, bs, ResourceType.Iron);
            }
        }

        private void TryEnsureHaulJob(BuildingId workplace, in BuildingState destState, ResourceType rt)
        {
            // Only enqueue if there is something to haul now
            if (!AnyHarvestProducerHasAmount(rt)) return;

            // Gate by THIS workplace free capacity (HQ/Warehouse)
            if (destState.Anchor.X == 0 && destState.Anchor.Y == 0)
                return;

            int cap = DestCap(destState.DefId, NormalizeLevel(destState.Level), rt);
            if (cap <= 0) return;

            int cur = GetAmountFromBuilding(destState, rt);
            if (cur >= cap) return;

            // Gate only by "ANY destination has free capacity" (NOT by workplace itself).
            // This preserves reroute behavior while preventing full-dest cancel/enqueue loops.

            int key = workplace.Value * 16 + (int)rt;

            if (_haulJobByWorkplaceAndType.TryGetValue(key, out var oldId))
            {
                if (_board.TryGet(oldId, out var old) && !IsTerminal(old.Status))
                    return;
            }

            var j = new Job
            {
                Archetype = JobArchetype.HaulBasic,
                Status = JobStatus.Created,
                Workplace = workplace,

                SourceBuilding = default,

                // Allow executor to pick a destination dynamically.
                // We'll still set default dest = workplace as "preferred".
                DestBuilding = workplace,

                Site = default,
                Tower = default,
                ResourceType = rt,
                Amount = 0,
                TargetCell = default,
                CreatedAt = 0
            };

            var newId = _board.Enqueue(j);
            _haulJobByWorkplaceAndType[key] = newId;
        }

        private void TryEnsureHaulJobToProducer(BuildingId workplace, in BuildingState workplaceState, ResourceType rt)
        {
            // Resolve producer destination (lumbercamp for wood, farmhouse for food)
            if (!TryGetProducerFor(rt, out var producer))
                return;

            // Only enqueue if there is something to haul now (pile exists for this producer+rt)
            if (_w.Piles == null || !_w.Piles.TryFindNonEmpty(rt, producer, out _))
                return;

            // Gate by producer local cap (avoid hauling into full producer -> cancel loops)
            if (_w.Buildings.Exists(producer))
            {
                var ps = _w.Buildings.Get(producer);
                int cap = HarvestLocalCap(ps.DefId, NormalizeLevel(ps.Level));
                int cur = GetAmountFromBuilding(ps, rt);
                if (cap > 0 && cur >= cap)
                    return;
            }

            // key must include workplace + producer + rt (prevent spam per pair)
            int key = (workplace.Value * 100000) + (producer.Value * 16) + (int)rt;

            if (_haulJobByWorkplaceAndType.TryGetValue(key, out var oldId))
            {
                if (_board.TryGet(oldId, out var old) && !IsTerminal(old.Status))
                    return;
            }

            var j = new Job
            {
                Archetype = JobArchetype.HaulBasic,
                Status = JobStatus.Created,
                Workplace = workplace,

                SourceBuilding = default,
                DestBuilding = producer, // IMPORTANT: deliver to producer

                Site = default,
                Tower = default,
                ResourceType = rt,
                Amount = 0,
                TargetCell = default,
                CreatedAt = 0
            };

            var newId = _board.Enqueue(j);
            _haulJobByWorkplaceAndType[key] = newId;
        }

        private bool AnyHaulDestinationHasFree(ResourceType rt)
        {
            for (int i = 0; i < _buildingIds.Count; i++)
            {
                var bid = _buildingIds[i];
                if (!_w.Buildings.Exists(bid)) continue;

                var bs = _w.Buildings.Get(bid);
                if (!bs.IsConstructed) continue;

                // HARDENING: In this project, anchors should never be (0,0) (buildableRect starts at 12,12).
                // If anchor is default, RunStart/placement hasn't fully applied yet => skip enqueue this tick.
                if (bs.Anchor.X == 0 && bs.Anchor.Y == 0)
                    continue;

                // destinations are Warehouse/HQ only
                if (!IsWarehouseWorkplace(bs.DefId)) continue;

                int cap = DestCap(bs.DefId, NormalizeLevel(bs.Level), rt);
                if (cap <= 0) continue;

                int cur = GetAmountFromBuilding(bs, rt);
                if (cur < cap) return true; // has free space
            }

            return false;
        }

        private bool TryGetProducerFor(ResourceType rt, out BuildingId producer)
        {
            // Deterministic: pick smallest BuildingId that is constructed and matches resource type
            producer = default;

            for (int i = 0; i < _buildingIds.Count; i++)
            {
                var bid = _buildingIds[i];
                if (!_w.Buildings.Exists(bid)) continue;

                var bs = _w.Buildings.Get(bid);
                if (!bs.IsConstructed) continue;
                if (!HasWorkRole(bs.DefId, WorkRoleFlags.Harvest)) continue;

                var prt = HarvestResourceType(bs.DefId);
                if (prt != rt) continue;

                // M4: only wood+food producers
                if (rt == ResourceType.Wood && !EqualsIgnoreCase(bs.DefId, "bld_lumbercamp_t1")) continue;
                if (rt == ResourceType.Food && !EqualsIgnoreCase(bs.DefId, "bld_farmhouse_t1")) continue;

                producer = bid;
                return true;
            }

            return false;
        }

        private bool AnyHarvestProducerHasAmount(ResourceType rt)
        {
            for (int i = 0; i < _buildingIds.Count; i++)
            {
                var bid = _buildingIds[i];
                if (!_w.Buildings.Exists(bid)) continue;

                var bs = _w.Buildings.Get(bid);
                if (!bs.IsConstructed) continue;
                if (!HasWorkRole(bs.DefId, WorkRoleFlags.Harvest)) continue;
                if (HarvestResourceType(bs.DefId) != rt) continue;

                if (GetAmountFromBuilding(bs, rt) > 0) return true;
            }
            return false;
        }

        private bool AnyPileHasAmount(ResourceType rt, BuildingId owner)
        {
            return _w.Piles != null && owner.Value != 0 && _w.Piles.TryFindNonEmpty(rt, owner, out _);
        }

        // -------------------------
        // Determinism helpers
        // -------------------------

        private void BuildSortedNpcIds()
        {
            _npcIds.Clear();
            foreach (var id in _w.Npcs.Ids) _npcIds.Add(id);
            _npcIds.Sort((a, b) => a.Value.CompareTo(b.Value));
        }

        private void BuildSortedBuildingIds()
        {
            _buildingIds.Clear();
            foreach (var id in _w.Buildings.Ids) _buildingIds.Add(id);
            _buildingIds.Sort((a, b) => a.Value.CompareTo(b.Value));
        }

        private void BuildWorkplaceHasNpcSet()
        {
            _workplacesWithNpc.Clear();
            for (int i = 0; i < _npcIds.Count; i++)
            {
                var nid = _npcIds[i];
                if (!_w.Npcs.Exists(nid)) continue;
                var ns = _w.Npcs.Get(nid);
                if (ns.Workplace.Value != 0) _workplacesWithNpc.Add(ns.Workplace.Value);
            }
        }

        private static bool IsTerminal(JobStatus s)
        {
            return s == JobStatus.Completed
                || s == JobStatus.Failed
                || s == JobStatus.Cancelled;
        }

        // -------------------------
        // Day12 mapping (Buildings.json)
        // -------------------------

        private static bool IsWarehouseWorkplace(string defId)
        {
            return EqualsIgnoreCase(defId, "bld_warehouse_t1")
                || EqualsIgnoreCase(defId, "bld_hq_t1");
        }

        // Harvest subset ONLY (do not include Forge)
        private static bool IsHarvestProducer(string defId)
        {
            return EqualsIgnoreCase(defId, "bld_farmhouse_t1")
                || EqualsIgnoreCase(defId, "bld_lumbercamp_t1")
                || EqualsIgnoreCase(defId, "bld_quarry_t1")
                || EqualsIgnoreCase(defId, "bld_ironhut_t1");
        }

        private static ResourceType HarvestResourceType(string defId)
        {
            if (EqualsIgnoreCase(defId, "bld_farmhouse_t1")) return ResourceType.Food;
            if (EqualsIgnoreCase(defId, "bld_lumbercamp_t1")) return ResourceType.Wood;
            if (EqualsIgnoreCase(defId, "bld_quarry_t1")) return ResourceType.Stone;
            if (EqualsIgnoreCase(defId, "bld_ironhut_t1")) return ResourceType.Iron;
            return ResourceType.Food;
        }

        private static int HarvestLocalCap(string defId, int level)
        {
            // Local Storage Caps (LOCKED)
            if (EqualsIgnoreCase(defId, "bld_farmhouse_t1")) return level == 1 ? 30 : level == 2 ? 60 : 90;
            if (EqualsIgnoreCase(defId, "bld_lumbercamp_t1")) return level == 1 ? 40 : level == 2 ? 80 : 120;
            if (EqualsIgnoreCase(defId, "bld_quarry_t1")) return level == 1 ? 40 : level == 2 ? 80 : 120;
            if (EqualsIgnoreCase(defId, "bld_ironhut_t1")) return level == 1 ? 30 : level == 2 ? 60 : 90;
            return 0;
        }

        // NEW: Dest caps for hauling (LOCKED)
        private static int DestCap(string defId, int level, ResourceType rt)
        {
            // Warehouse: 300/600/1000 each (Wood/Food/Stone/Iron), Ammo=0
            if (EqualsIgnoreCase(defId, "bld_warehouse_t1"))
            {
                return rt switch
                {
                    ResourceType.Wood or ResourceType.Food or ResourceType.Stone or ResourceType.Iron
                        => level == 1 ? 300 : level == 2 ? 600 : 1000,
                    _ => 0
                };
            }

            // HQ: 120/180/240 each (core only), Ammo=0
            if (EqualsIgnoreCase(defId, "bld_hq_t1"))
            {
                return rt switch
                {
                    ResourceType.Wood or ResourceType.Food or ResourceType.Stone or ResourceType.Iron
                        => level == 1 ? 120 : level == 2 ? 180 : 240,
                    _ => 0
                };
            }

            return 0;
        }

        private static int GetAmountFromBuilding(in BuildingState bs, ResourceType rt)
        {
            return rt switch
            {
                ResourceType.Wood => bs.Wood,
                ResourceType.Food => bs.Food,
                ResourceType.Stone => bs.Stone,
                ResourceType.Iron => bs.Iron,
                ResourceType.Ammo => bs.Ammo,
                _ => 0
            };
        }

        private static int NormalizeLevel(int level) => level <= 0 ? 1 : (level > 3 ? 3 : level);

        private static bool EqualsIgnoreCase(string a, string b)
        {
            if (a == null || b == null) return false;
            return string.Equals(a, b, StringComparison.OrdinalIgnoreCase);
        }
    }
}
