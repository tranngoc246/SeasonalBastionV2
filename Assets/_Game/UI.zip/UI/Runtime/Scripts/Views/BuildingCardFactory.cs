using UnityEngine;
using UnityEngine.UIElements;

namespace SeasonalBastion.UI.Views
{
    public sealed class BuildingCardFactory
    {
        private const string TemplatePath = "UI/Runtime/UXML/BuildingCard";
        private readonly VisualTreeAsset _template;

        public BuildingCardFactory()
        {
            _template = Resources.Load<VisualTreeAsset>(TemplatePath);
        }

        public BuildingCardView Create()
        {
            if (_template == null)
            {
                Debug.LogError($"[BuildingCardFactory] Failed to load BuildingCard template at Resources/{TemplatePath}.uxml");
                return null;
            }

            var root = _template.Instantiate();
            return root != null ? new BuildingCardView(root) : null;
        }
    }
}
