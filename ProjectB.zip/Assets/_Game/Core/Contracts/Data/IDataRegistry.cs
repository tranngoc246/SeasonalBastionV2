﻿using System.Collections.Generic;

namespace SeasonalBastion.Contracts
{
    public interface IDataRegistry
    {
        T GetDef<T>(string id) where T : UnityEngine.Object;
        bool TryGetDef<T>(string id, out T def) where T : UnityEngine.Object;

        // common typed accessors:
        BuildingDef GetBuilding(string id);
        EnemyDef GetEnemy(string id);
        WaveDef GetWave(string id);
        RewardDef GetReward(string id);
        RecipeDef GetRecipe(string id);
        NpcDef GetNpc(string id);
        TowerDef GetTower(string id);

        // BuildablesGraph (Upgrade)
        bool TryGetBuildableNode(string id, out BuildableNodeDef node);
        IReadOnlyList<UpgradeEdgeDef> GetUpgradeEdgesFrom(string fromNodeId);
        bool TryGetUpgradeEdge(string edgeId, out UpgradeEdgeDef edge);

        // UI helper: nếu node có trong graph thì theo node.Placeable; không có => legacy true
        bool IsPlaceableBuildable(string nodeId);
    }
}
