﻿using System.Collections.Generic;
using SeasonalBastion.Contracts;
using UnityEngine;
using UnityEngine.InputSystem;

namespace SeasonalBastion.DebugTools
{
    public enum DebugHubTab
    {
        Home = 0,
        Notifications = 1,
        WorldIndex = 2,
        Npc = 3,
        Storage = 4
    }

    public enum DebugHubMode
    {
        None = 0,
        Build = 1,
        Road = 2,
        Npc = 3,
        Storage = 4
    }

    public static class DebugHubState
    {
        public static bool Enabled;
    }

    /// <summary>
    /// Single Debug HUD Hub (Level 2):
    /// - Only ONE panel on screen
    /// - Hub owns all mode toggles (F-keys)
    /// - Tools become hub-controlled: no standalone toggles, no extra HUD panels
    /// </summary>
    public sealed class DebugHUDHub : MonoBehaviour
    {
        [Header("Bootstrap")]
        [SerializeField] private GameBootstrap _bootstrap;

        [Header("Modules (optional auto-find)")]
        [SerializeField] private DebugBuildingTool _buildTool;
        [SerializeField] private DebugRoadTool _roadTool;
        [SerializeField] private DebugNpcTool _npcTool;
        [SerializeField] private DebugStorageHUD _storageHud;
        [SerializeField] private DebugNotificationsHUD _notiHud;
        [SerializeField] private DebugWorldIndexHUD _worldIndexHud;
        [SerializeField] private DebugCombatLaneHUD _combatLaneHud;
        [SerializeField] private DebugRunClockHUD _runClockHud;
        [SerializeField] private DebugWaveHUD _waveHud;

        [Header("Hotkeys (Hub only)")]
        [SerializeField] private Key _toggleUiKey = Key.F1;
        [SerializeField] private Key _modeBuildKey = Key.F2;
        [SerializeField] private Key _modeRoadKey = Key.F3;
        [SerializeField] private Key _modeNpcKey = Key.F4;
        [SerializeField] private Key _modeStorageKey = Key.F5;

        [SerializeField] private Key _tabNotiKey = Key.F6;
        [SerializeField] private Key _tabWorldIndexKey = Key.F7;

        [SerializeField] private Key _clearModeKey = Key.Escape;

        [Header("State")]
        [SerializeField] private bool _showUi = true;
        [SerializeField] private DebugHubMode _mode = DebugHubMode.None;
        [SerializeField] private DebugHubTab _tab = DebugHubTab.Home;

        // VS3 QA: Quick Debug always visible + optional Advanced.
        [SerializeField] private bool _showAdvanced = false;

        // Quick spawn enemy
        [SerializeField] private string _quickEnemyDefId = "Swarmling";
        [SerializeField] private int _quickLaneId = 0;
        [SerializeField] private int _quickSpawnCount = 1;

        [SerializeField] private string _quickGiveAmtStr = "200";

        // tmp lists (avoid modifying stores while iterating)
        private readonly List<EnemyId> _enemyIdsTmp = new List<EnemyId>(128);
        private readonly List<TowerId> _towerIdsTmp = new List<TowerId>(64);
        private readonly List<SiteId> _siteIdsTmp = new List<SiteId>(64);

        [SerializeField] private bool _selfPollHotkeysWhenNoRouter = true;
        private bool _hasRouter;

        // Day34: Home scroll + section toggles (IMGUI)
        private Vector2 _homeScroll;
        private bool _homeShowData = true;
        private bool _homeShowRunClock = true;
        private bool _homeShowHints = true;
        private bool _homeShowLanes = true;
        private bool _homeShowSaveLoad = true;
        private bool _homeShowWave = true;

        private bool _homeShowRewards = true;

        // EndSeasonRewardRequested debug listener
        private bool _rewardListenerBound;
        private int _endSeasonRewardReqCount;
        private EndSeasonRewardRequested _lastEndSeasonRewardReq;
        private bool _hasLastEndSeasonRewardReq;
        private float _lastEndSeasonRewardRealtime;

        private GameServices _gs;

        // --- Data validation HUD (Day17) ---
        private readonly List<string> _dataErrors = new List<string>(128);
        private Vector2 _dataScroll;
        private bool _dataLastOk = true;
        private string _dataLastSummary = "Not validated";

        private readonly List<string> _buildSlotsTmp = new List<string>(8);

        private DebugSaveLoadHUD _saveLoadHUD = new DebugSaveLoadHUD();

        private void Awake()
        {
            DebugHubState.Enabled = true;

            if (_bootstrap == null) _bootstrap = FindObjectOfType<GameBootstrap>();
            _gs = _bootstrap != null ? _bootstrap.Services : null;

            TryBindRewardListener();

            if (_buildTool == null) _buildTool = FindObjectOfType<DebugBuildingTool>(true);
            if (_roadTool == null) _roadTool = FindObjectOfType<DebugRoadTool>(true);
            if (_npcTool == null) _npcTool = FindObjectOfType<DebugNpcTool>(true);

            if (_storageHud == null) _storageHud = FindObjectOfType<DebugStorageHUD>(true);
            if (_notiHud == null) _notiHud = FindObjectOfType<DebugNotificationsHUD>(true);
            if (_worldIndexHud == null) _worldIndexHud = FindObjectOfType<DebugWorldIndexHUD>(true);
            if (_combatLaneHud == null) _combatLaneHud = FindObjectOfType<DebugCombatLaneHUD>(true);
            if (_runClockHud == null) _runClockHud = FindObjectOfType<DebugRunClockHUD>(true);
            if (_waveHud == null) _waveHud = FindObjectOfType<DebugWaveHUD>(true);

            // Hub-control: disable standalone HUD + disable standalone toggle hotkeys
            if (_buildTool != null) _buildTool.SetHubControlled(true);
            if (_roadTool != null) _roadTool.SetHubControlled(true);
            if (_npcTool != null) _npcTool.SetHubControlled(true);

            if (_storageHud != null) _storageHud.SetHubControlled(true);
            if (_notiHud != null) _notiHud.SetHubControlled(true);
            if (_worldIndexHud != null) _worldIndexHud.SetHubControlled(true);
            if (_combatLaneHud != null) _combatLaneHud.SetHubControlled(true);
            if (_runClockHud != null) _runClockHud.SetHubControlled(true);
            if (_waveHud != null) _waveHud.SetHubControlled(true);

            var kb = Keyboard.current;
            if (kb != null) HandleHotkeys(kb);

            ApplyMode(_mode);

            _hasRouter = FindObjectOfType<DebugInputRouter>(true) != null;
        }

        private void OnDestroy()
        {
            DebugHubState.Enabled = false;
        }
        private void Update()
        {
            // Fallback: nếu scene chưa có DebugInputRouter thì Hub tự poll hotkeys để khỏi “mất phím”.
            if (_selfPollHotkeysWhenNoRouter)
            {
                // Nếu sau này bạn add Router vào scene, Hub sẽ tự tắt fallback.
                _hasRouter = _hasRouter || (FindObjectOfType<DebugInputRouter>(true) != null);

                if (!_hasRouter)
                {
                    var kb = Keyboard.current;
                    if (kb != null) HandleHotkeys(kb);
                }
            }

            if (_bootstrap == null) _bootstrap = FindObjectOfType<GameBootstrap>();
            _gs ??= _bootstrap != null ? _bootstrap.Services : null;

            TryBindRewardListener();

            if (_buildTool == null) _buildTool = FindObjectOfType<DebugBuildingTool>();
            if (_roadTool == null) _roadTool = FindObjectOfType<DebugRoadTool>();
            if (_npcTool == null) _npcTool = FindObjectOfType<DebugNpcTool>();

            if (_storageHud == null) _storageHud = FindObjectOfType<DebugStorageHUD>();
            if (_notiHud == null) _notiHud = FindObjectOfType<DebugNotificationsHUD>();
            if (_worldIndexHud == null) _worldIndexHud = FindObjectOfType<DebugWorldIndexHUD>();
            if (_combatLaneHud == null) _combatLaneHud = FindObjectOfType<DebugCombatLaneHUD>();
            if (_runClockHud == null) _runClockHud = FindObjectOfType<DebugRunClockHUD>();
            if (_waveHud == null) _waveHud = FindObjectOfType<DebugWaveHUD>();

            ApplyMode(_mode);
        }

        public void HandleHotkeys(Keyboard kb)
        {
            static bool Pressed(Keyboard k, Key key)
            {
                if (k == null || key == Key.None) return false;
                var c = k[key];
                return c != null && c.wasPressedThisFrame;
            }

            if (Pressed(kb, _toggleUiKey))
                _showUi = !_showUi;

            if (Pressed(kb, _clearModeKey))
                ApplyMode(DebugHubMode.None);

            if (Pressed(kb, _modeBuildKey)) { ApplyMode(DebugHubMode.Build); _tab = DebugHubTab.Home; }
            if (Pressed(kb, _modeRoadKey)) { ApplyMode(DebugHubMode.Road); _tab = DebugHubTab.Home; }
            if (Pressed(kb, _modeNpcKey)) { ApplyMode(DebugHubMode.Npc); _tab = DebugHubTab.Npc; }
            if (Pressed(kb, _modeStorageKey)) { ApplyMode(DebugHubMode.Storage); _tab = DebugHubTab.Storage; }

            if (Pressed(kb, _tabNotiKey)) _tab = DebugHubTab.Notifications;
            if (Pressed(kb, _tabWorldIndexKey)) _tab = DebugHubTab.WorldIndex;
        }

        private void ApplyMode(DebugHubMode m)
        {
            _mode = m;

            if (_buildTool != null) _buildTool.SetEnabledFromHub(m == DebugHubMode.Build);
            if (_roadTool != null) _roadTool.SetEnabledFromHub(m == DebugHubMode.Road);
            if (_npcTool != null) _npcTool.SetEnabledFromHub(m == DebugHubMode.Npc);
            if (_storageHud != null) _storageHud.SetEnabledFromHub(m == DebugHubMode.Storage);
        }

        private void TryBindRewardListener()
        {
            if (_rewardListenerBound) return;
            if (_gs == null || _gs.EventBus == null) return;

            _gs.EventBus.Subscribe<EndSeasonRewardRequested>(OnEndSeasonRewardRequested);
            _rewardListenerBound = true;
        }

        private void OnEndSeasonRewardRequested(EndSeasonRewardRequested ev)
        {
            _endSeasonRewardReqCount++;
            _lastEndSeasonRewardReq = ev;
            _hasLastEndSeasonRewardReq = true;
            _lastEndSeasonRewardRealtime = Time.realtimeSinceStartup;
        }

        private void OnGUI()
        {
            DebugHubState.Enabled = _showUi;
            if (!_showUi) return;
            GUILayout.BeginArea(new Rect(10, 50, 640, (Screen.height - 20)), GUI.skin.box);

            GUILayout.Label("[DebugHUDHub] VS3 QA QUICK | F1 UI | F2 Build | F3 Road | F4 NPC | F5 Storage | F6 Noti | F7 Index | Esc None");

            GUILayout.BeginHorizontal();
            _showAdvanced = GUILayout.Toggle(_showAdvanced, "Advanced", GUILayout.Width(110));
            GUILayout.Label($"Mode: {_mode}");
            GUILayout.EndHorizontal();

            GUILayout.Space(8);

            DrawQuick(); 

            if (_showAdvanced)
            {
                GUILayout.Space(10);
                DrawAdvancedTabs();
            }

            GUILayout.EndArea();
        }

        private void DrawQuick()
        {
            if (_gs == null)
            {
                GUILayout.Label("GameServices = null");
                return;
            }

            // ===== TimeScale =====
            GUILayout.Label("TimeScale");
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("0x", GUILayout.Width(50))) _gs.RunClock?.SetTimeScale(0f);
            if (GUILayout.Button("1x", GUILayout.Width(50))) _gs.RunClock?.SetTimeScale(1f);
            if (GUILayout.Button("2x", GUILayout.Width(50))) _gs.RunClock?.SetTimeScale(2f);
            if (GUILayout.Button("3x", GUILayout.Width(50))) _gs.RunClock?.SetTimeScale(3f);
            if (GUILayout.Button("5x", GUILayout.Width(50))) _gs.RunClock?.SetTimeScale(5f);
            GUILayout.EndHorizontal();

            GUILayout.Space(6);

            // ===== Build =====
            GUILayout.Label("Build");
            if (GUILayout.Button("Complete ALL build sites now", GUILayout.Width(260)))
                Quick_CompleteAllBuildSites();

            if (GUILayout.Button("Complete CURRENT site under mouse", GUILayout.Width(260)))
                Quick_CompleteCurrentSiteUnderMouse();

            GUILayout.Space(6);

            // ===== Resources =====
            GUILayout.Label("Resources");
            GUILayout.BeginHorizontal();
            GUILayout.Label("Amt", GUILayout.Width(30));
            _quickGiveAmtStr = GUILayout.TextField(_quickGiveAmtStr, GUILayout.Width(60));
            if (GUILayout.Button("100", GUILayout.Width(50))) _quickGiveAmtStr = "100";
            if (GUILayout.Button("300", GUILayout.Width(50))) _quickGiveAmtStr = "300";
            if (GUILayout.Button("1000", GUILayout.Width(55))) _quickGiveAmtStr = "1000";
            GUILayout.EndHorizontal();

            int giveAmt = 200;
            if (!int.TryParse(_quickGiveAmtStr, out giveAmt) || giveAmt <= 0) giveAmt = 200;

            GUILayout.BeginHorizontal();
            if (GUILayout.Button("Wood", GUILayout.Width(70))) Quick_GiveResource(ResourceType.Wood, giveAmt);
            if (GUILayout.Button("Food", GUILayout.Width(70))) Quick_GiveResource(ResourceType.Food, giveAmt);
            if (GUILayout.Button("Stone", GUILayout.Width(70))) Quick_GiveResource(ResourceType.Stone, giveAmt);
            if (GUILayout.Button("Iron", GUILayout.Width(70))) Quick_GiveResource(ResourceType.Iron, giveAmt);
            if (GUILayout.Button("Ammo", GUILayout.Width(70))) Quick_GiveResource(ResourceType.Ammo, giveAmt);
            GUILayout.EndHorizontal();

            GUILayout.Space(6);

            // ===== Ammo =====
            GUILayout.Label("Ammo");
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("Drain ALL towers to 0", GUILayout.Width(170)))
                Quick_DrainAllTowersToZero();
            if (GUILayout.Button("Refill ALL towers", GUILayout.Width(150)))
                Quick_RefillAllTowers();
            if (_gs.AmmoService is AmmoService a)
            {
                string label = a.DevHook_Enabled ? "DevHook: ON" : "DevHook: OFF";
                if (GUILayout.Button(label, GUILayout.Width(120))) a.DevHook_Enabled = !a.DevHook_Enabled;
            }
            GUILayout.EndHorizontal();

            GUILayout.Space(6);

            // ===== Combat =====
            GUILayout.Label("Combat");
            GUILayout.BeginHorizontal();
            GUILayout.Label("DefId", GUILayout.Width(40));
            _quickEnemyDefId = GUILayout.TextField(_quickEnemyDefId, GUILayout.Width(140));
            GUILayout.Label("Lane", GUILayout.Width(35));
            var laneStr = GUILayout.TextField(_quickLaneId.ToString(), GUILayout.Width(40));
            if (int.TryParse(laneStr, out var l)) _quickLaneId = l;
            GUILayout.Label("x", GUILayout.Width(12));
            var cntStr = GUILayout.TextField(_quickSpawnCount.ToString(), GUILayout.Width(40));
            if (int.TryParse(cntStr, out var c)) _quickSpawnCount = Mathf.Clamp(c, 1, 50);
            if (GUILayout.Button("Spawn", GUILayout.Width(80)))
                Quick_SpawnEnemy(_quickEnemyDefId, _quickLaneId, _quickSpawnCount);
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            if (GUILayout.Button("Kill ALL enemies", GUILayout.Width(150)))
                Quick_KillAllEnemies();
            if (GUILayout.Button("Force Resolve Wave", GUILayout.Width(170)))
                _gs.CombatService?.ForceResolveWave();
            GUILayout.EndHorizontal();

            GUILayout.Space(6);

            // ===== NPC =====
            GUILayout.Label("NPC (Assign + Job)");
            GUILayout.BeginHorizontal();
            bool npcMode = _mode == DebugHubMode.Npc;
            if (GUILayout.Button(npcMode ? "NPC Assign: ON" : "NPC Assign: OFF", GUILayout.Width(150)))
            {
                ApplyMode(npcMode ? DebugHubMode.None : DebugHubMode.Npc);
            }
            GUILayout.Label("(Bật ON để click LMB lên building cell gán NPC)");
            GUILayout.EndHorizontal();

            if (_npcTool != null)
                _npcTool.DrawQuickGUI();
            else
                GUILayout.Label("DebugNpcTool not found in scene.");
        }

        private void DrawAdvancedTabs()
        {
            GUILayout.Label($"Tab: {_tab}");
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("Home", GUILayout.Width(90))) _tab = DebugHubTab.Home;
            if (GUILayout.Button("Noti (F6)", GUILayout.Width(120))) _tab = DebugHubTab.Notifications;
            if (GUILayout.Button("Index (F7)", GUILayout.Width(120))) _tab = DebugHubTab.WorldIndex;
            if (GUILayout.Button("NPC", GUILayout.Width(90))) _tab = DebugHubTab.Npc;
            if (GUILayout.Button("Storage", GUILayout.Width(110))) _tab = DebugHubTab.Storage;
            _homeShowRewards = GUILayout.Toggle(_homeShowRewards, "Rewards", GUILayout.Width(90));
            _homeShowHints = GUILayout.Toggle(_homeShowHints, "Hints", GUILayout.Width(70));
            GUILayout.EndHorizontal();

            GUILayout.Space(8);

            switch (_tab)
            {
                case DebugHubTab.Home:
                    DrawHome();
                    break;

                case DebugHubTab.Notifications:
                    if (_notiHud != null) _notiHud.DrawHubGUI();
                    else GUILayout.Label("DebugNotificationsHUD not found in scene.");
                    break;

                case DebugHubTab.WorldIndex:
                    if (_worldIndexHud != null) _worldIndexHud.DrawHubGUI();
                    else GUILayout.Label("DebugWorldIndexHUD not found in scene.");
                    break;

                case DebugHubTab.Npc:
                    if (_npcTool != null) _npcTool.DrawHubGUI();
                    else GUILayout.Label("DebugNpcTool not found in scene.");
                    break;

                case DebugHubTab.Storage:
                    if (_storageHud != null) _storageHud.DrawHubGUI();
                    else GUILayout.Label("DebugStorageHUD not found in scene.");
                    break;
            }
        }

        private void Quick_CompleteAllBuildSites()
        {
            if (_gs?.WorldState == null) return;
            var sites = _gs.WorldState.Sites;
            if (sites == null) return;

            _siteIdsTmp.Clear();
            foreach (var sid in sites.Ids) _siteIdsTmp.Add(sid);

            int changed = 0;
            for (int i = 0; i < _siteIdsTmp.Count; i++)
            {
                var sid = _siteIdsTmp[i];
                if (!sites.Exists(sid)) continue;
                var st = sites.Get(sid);
                if (!st.IsActive) continue;

                st.RemainingCosts?.Clear();
                st.RemainingCosts = null;
                if (st.WorkSecondsTotal <= 0f) st.WorkSecondsTotal = 0.1f;
                st.WorkSecondsDone = st.WorkSecondsTotal;

                sites.Set(sid, st);
                changed++;
            }

            if (_gs.BuildOrderService is BuildOrderService bos)
                bos.Tick(0.0001f);

            _gs.NotificationService?.Push("debug_build_instant", "Debug", $"Instant completed {changed} build sites.", NotificationSeverity.Info, default, 0.2f, true);
        }

        private void Quick_CompleteCurrentSiteUnderMouse()
        {
            if (_gs?.WorldState == null || _gs.GridMap == null) return;
            if (!SeasonalBastion.DebugTools.MouseCellSharedState.HasValue)
            {
                _gs.NotificationService?.Push("debug_site_none", "Debug", "No hover cell (MouseCellSharedState).", NotificationSeverity.Warning, default, 0.2f, true);
                return;
            }

            if (!TryFindActiveSiteFromHover(out var sid, out var st))
            {
                _gs.NotificationService?.Push("debug_site_notfound", "Debug", "No active build/upgrade site found under mouse.", NotificationSeverity.Info, default, 0.2f, true);
                return;
            }

            ForceCompleteSite(sid, st);
        }

        private bool TryFindActiveSiteFromHover(out SiteId sid, out BuildSiteState site)
        {
            sid = default;
            site = default;

            var cell = SeasonalBastion.DebugTools.MouseCellSharedState.Cell;
            var occ = _gs.GridMap.Get(cell);

            // Case 1: PlaceNew site occupies grid => GridMap stores SiteId
            if (occ.Kind == CellOccupancyKind.Site && occ.Site.Value != 0 && _gs.WorldState.Sites.Exists(occ.Site))
            {
                var s = _gs.WorldState.Sites.Get(occ.Site);
                if (s.IsActive)
                {
                    sid = occ.Site;
                    site = s;
                    return true;
                }
            }

            // Case 2: Upgrade site does NOT occupy grid => find by TargetBuilding
            if (occ.Kind == CellOccupancyKind.Building && occ.Building.Value != 0)
            {
                foreach (var x in _gs.WorldState.Sites.Ids)
                {
                    if (!_gs.WorldState.Sites.Exists(x)) continue;
                    var s = _gs.WorldState.Sites.Get(x);
                    if (!s.IsActive) continue;
                    if (s.TargetBuilding.Value == occ.Building.Value)
                    {
                        sid = x;
                        site = s;
                        return true;
                    }
                }
            }

            return false;
        }

        private void ForceCompleteSite(SiteId sid, BuildSiteState st)
        {
            var sites = _gs.WorldState.Sites;
            if (!sites.Exists(sid)) return;

            st.RemainingCosts?.Clear();
            st.RemainingCosts = null;

            if (st.WorkSecondsTotal <= 0f) st.WorkSecondsTotal = 0.1f;
            st.WorkSecondsDone = st.WorkSecondsTotal;

            sites.Set(sid, st);

            // Tick nhẹ để BuildOrderService detect completion ngay
            if (_gs.BuildOrderService is BuildOrderService bos)
                bos.Tick(0.0001f);

            _gs.NotificationService?.Push("debug_site_complete_one", "Debug",
                $"Completed site {sid.Value} (kind={(st.IsUpgrade ? "Upgrade" : "PlaceNew")}).",
                NotificationSeverity.Info, default, 0.2f, true);
        }

        private void Quick_GiveResource(ResourceType type, int amount)
        {
            if (_gs?.WorldState == null || _gs.StorageService == null || _gs.DataRegistry == null) return;
            if (amount <= 0) return;

            int remaining = amount;
            int addedTotal = 0;

            // Pass order deterministic:
            // - Non-ammo: HQ -> Warehouses -> any store that CanStore
            // - Ammo: Armory -> Forge -> any store that CanStore
            if (type == ResourceType.Ammo)
            {
                addedTotal += GiveToPreferredBuildings(type, ref remaining, preferArmory: true);
                addedTotal += GiveToPreferredBuildings(type, ref remaining, preferForge: true);
            }
            else
            {
                addedTotal += GiveToPreferredBuildings(type, ref remaining, preferHQ: true);
                addedTotal += GiveToPreferredBuildings(type, ref remaining, preferWarehouse: true);
            }

            // Fallback any
            if (remaining > 0)
            {
                foreach (var bid in _gs.WorldState.Buildings.Ids)
                {
                    if (remaining <= 0) break;
                    if (!_gs.WorldState.Buildings.Exists(bid)) continue;

                    var bs = _gs.WorldState.Buildings.Get(bid);
                    if (!bs.IsConstructed) continue;

                    int add = _gs.StorageService.Add(bid, type, remaining);
                    if (add <= 0) continue;

                    remaining -= add;
                    addedTotal += add;
                }
            }

            _gs.NotificationService?.Push("debug_give_res", "Debug",
                $"Give {type} {amount} -> added {addedTotal} (remain {remaining}).",
                NotificationSeverity.Info, default, 0.2f, true);
        }

        private int GiveToPreferredBuildings(ResourceType type, ref int remaining,
            bool preferHQ = false, bool preferWarehouse = false, bool preferArmory = false, bool preferForge = false)
        {
            if (remaining <= 0) return 0;

            int added = 0;
            foreach (var bid in _gs.WorldState.Buildings.Ids)
            {
                if (remaining <= 0) break;
                if (!_gs.WorldState.Buildings.Exists(bid)) continue;

                var bs = _gs.WorldState.Buildings.Get(bid);
                if (!bs.IsConstructed) continue;

                BuildingDef def = null;
                try { def = _gs.DataRegistry.GetBuilding(bs.DefId); } catch { }
                if (def == null) continue;

                if (preferHQ && !def.IsHQ) continue;
                if (preferWarehouse && !def.IsWarehouse) continue;
                if (preferArmory && !def.IsArmory) continue;
                if (preferForge && !def.IsForge) continue;

                int a = _gs.StorageService.Add(bid, type, remaining);
                if (a <= 0) continue;

                remaining -= a;
                added += a;
            }
            return added;
        }

        private void Quick_DrainAllTowersToZero()
        {
            if (_gs?.WorldState == null) return;
            var towers = _gs.WorldState.Towers;
            if (towers == null) return;

            _towerIdsTmp.Clear();
            foreach (var tid in towers.Ids) _towerIdsTmp.Add(tid);

            int changed = 0;
            for (int i = 0; i < _towerIdsTmp.Count; i++)
            {
                var tid = _towerIdsTmp[i];
                if (!towers.Exists(tid)) continue;
                var ts = towers.Get(tid);
                ts.Ammo = 0;
                towers.Set(tid, ts);
                _gs.AmmoService?.NotifyTowerAmmoChanged(ts.Id, ts.Ammo, ts.AmmoCap);
                changed++;
            }

            _gs.NotificationService?.Push("debug_ammo_drain", "Debug", $"Drained {changed} towers to 0.", NotificationSeverity.Info, default, 0.2f, true);
        }

        private void Quick_RefillAllTowers()
        {
            if (_gs?.WorldState == null) return;
            var towers = _gs.WorldState.Towers;
            if (towers == null) return;

            _towerIdsTmp.Clear();
            foreach (var tid in towers.Ids) _towerIdsTmp.Add(tid);

            int changed = 0;
            for (int i = 0; i < _towerIdsTmp.Count; i++)
            {
                var tid = _towerIdsTmp[i];
                if (!towers.Exists(tid)) continue;
                var ts = towers.Get(tid);
                ts.Ammo = ts.AmmoCap;
                towers.Set(tid, ts);
                _gs.AmmoService?.NotifyTowerAmmoChanged(ts.Id, ts.Ammo, ts.AmmoCap);
                changed++;
            }

            _gs.NotificationService?.Push("debug_ammo_refill", "Debug", $"Refilled {changed} towers.", NotificationSeverity.Info, default, 0.2f, true);
        }

        private void Quick_SpawnEnemy(string enemyDefId, int laneId, int count)
        {
            if (_gs?.WorldState == null || _gs.DataRegistry == null || _gs.RunStartRuntime == null) return;
            if (_gs.RunStartRuntime.Lanes == null || !_gs.RunStartRuntime.Lanes.TryGetValue(laneId, out var lane))
            {
                Debug.LogWarning($"[DebugHUDHub] Lane {laneId} not found.");
                return;
            }

            EnemyDef def;
            try { def = _gs.DataRegistry.GetEnemy(enemyDefId); }
            catch
            {
                Debug.LogWarning($"[DebugHUDHub] EnemyDef not found: '{enemyDefId}'");
                return;
            }

            int spawned = 0;
            for (int i = 0; i < count; i++)
            {
                var st = new EnemyState
                {
                    DefId = enemyDefId,
                    Cell = lane.StartCell,
                    Hp = def.MaxHp,
                    Lane = laneId,
                    MoveProgress01 = 0f
                };

                var id = _gs.WorldState.Enemies.Create(st);
                st.Id = id;
                _gs.WorldState.Enemies.Set(id, st);
                spawned++;
            }

            _gs.NotificationService?.Push("debug_spawn_enemy", "Debug", $"Spawned {spawned} '{enemyDefId}' lane {laneId}.", NotificationSeverity.Info, default, 0.2f, true);
        }

        private void Quick_KillAllEnemies()
        {
            if (_gs?.WorldState == null) return;
            var enemies = _gs.WorldState.Enemies;
            if (enemies == null) return;

            _enemyIdsTmp.Clear();
            foreach (var eid in enemies.Ids) _enemyIdsTmp.Add(eid);

            int killed = 0;
            for (int i = _enemyIdsTmp.Count - 1; i >= 0; i--)
            {
                var eid = _enemyIdsTmp[i];
                if (!enemies.Exists(eid)) continue;
                enemies.Destroy(eid);
                killed++;
            }

            _gs.NotificationService?.Push("debug_kill_enemies", "Debug", $"Killed {killed} enemies.", NotificationSeverity.Info, default, 0.2f, true);
        }

        private void ValidateDataNow()
        {
            _dataErrors.Clear();

            if (_gs == null)
            {
                _dataLastOk = false;
                _dataLastSummary = "GameServices is null";
                _dataErrors.Add(_dataLastSummary);
                return;
            }

            var validator = _gs.DataValidator;
            var registry = _gs.DataRegistry;
            if (validator == null || registry == null)
            {
                _dataLastOk = false;
                _dataLastSummary = "Missing DataValidator/DataRegistry";
                _dataErrors.Add(_dataLastSummary);
                return;
            }

            _dataLastOk = validator.ValidateAll(registry, _dataErrors);
            _dataLastSummary = _dataLastOk ? "OK" : $"FAIL ({_dataErrors.Count} errors)";

            if (!_dataLastOk)
            {
                try
                {
                    _gs.NotificationService?.Push("data_invalid", "Data INVALID", _dataLastSummary, NotificationSeverity.Error, default, cooldownSeconds: 0f, dedupeByKey: true);
                }
                catch { }
            }
        }

        private void DrawHome()
        {
            // ===== Top summary (no scroll) =====
            GUILayout.Label("Active Modules:");
            GUILayout.Label($"BuildTool: {(_buildTool != null ? "OK" : "missing")}  | RoadTool: {(_roadTool != null ? "OK" : "missing")}  | NpcTool: {(_npcTool != null ? "OK" : "missing")}");
            GUILayout.Label($"NotiHUD: {(_notiHud != null ? "OK" : "missing")}  | WorldIndexHUD: {(_worldIndexHud != null ? "OK" : "missing")}  | StorageHUD: {(_storageHud != null ? "OK" : "missing")}");

            GUILayout.Space(6);
            GUILayout.Label("Notes:");
            GUILayout.Label("- All old standalone toggle keys are disabled (B/R/N/H/I/S).");
            GUILayout.Label("- Tools only respond to inputs when their mode is active.");

            GUILayout.Space(8);
            if (_gs != null && _gs.JobBoard is JobBoard jb)
                GUILayout.Label($"HaulBasic jobs active: {jb.CountActiveJobs(JobArchetype.HaulBasic)}");

            if (_mode == DebugHubMode.Build && _gs != null && _buildTool != null && _gs.UnlockService != null)
            {
                GUILayout.Space(8);
                GUILayout.Label("Build Slots (Unlocked only)");

                _buildTool.GetBuildSlotDefs(_buildSlotsTmp);

                bool any = false;
                for (int i = 0; i < _buildSlotsTmp.Count; i++)
                {
                    var defId = _buildSlotsTmp[i];
                    if (string.IsNullOrEmpty(defId)) continue;

                    if (_gs.UnlockService.IsUnlocked(defId))
                    {
                        any = true;
                        GUILayout.Label($"{i + 1}: {defId}");
                    }
                }

                if (!any)
                    GUILayout.Label("(none unlocked in current time)");
            }

            GUILayout.Space(8);

            // ===== Section toggles (compact) =====
            GUILayout.BeginHorizontal();
            _homeShowData = GUILayout.Toggle(_homeShowData, "Data", GUILayout.Width(60));
            _homeShowRunClock = GUILayout.Toggle(_homeShowRunClock, "Clock", GUILayout.Width(70));
            _homeShowLanes = GUILayout.Toggle(_homeShowLanes, "Lanes", GUILayout.Width(70));
            _homeShowSaveLoad = GUILayout.Toggle(_homeShowSaveLoad, "Save", GUILayout.Width(60));
            _homeShowWave = GUILayout.Toggle(_homeShowWave, "Wave", GUILayout.Width(70));
            GUILayout.EndHorizontal();

            // ===== Scrollable content =====
            _homeScroll = GUILayout.BeginScrollView(_homeScroll, GUILayout.ExpandHeight(true));

            // ---- Day17: Data Validator ----
            if (_homeShowData)
            {
                GUILayout.Space(10);
                GUILayout.Label("Day17: Data Validator");

                GUILayout.BeginHorizontal();
                if (GUILayout.Button("Validate Data", GUILayout.Width(140)))
                    ValidateDataNow();
                GUILayout.Label($"Result: {_dataLastSummary}");
                GUILayout.EndHorizontal();

                if (!_dataLastOk)
                {
                    GUILayout.Label("Errors:");
                    _dataScroll = GUILayout.BeginScrollView(_dataScroll, GUILayout.Height(240));
                    int show = Mathf.Min(_dataErrors.Count, 50);
                    for (int i = 0; i < show; i++)
                        GUILayout.Label("- " + _dataErrors[i]);
                    if (_dataErrors.Count > show)
                        GUILayout.Label($"...({_dataErrors.Count - show} more)");
                    GUILayout.EndScrollView();
                }

                GUILayout.Space(6);
            }

            // ---- EndSeasonRewardRequested ----
            if (_homeShowRewards)
            {
                GUILayout.Space(10);
                GUILayout.Label("EndSeasonRewardRequested (Reward placeholder)");

                GUILayout.BeginHorizontal();
                GUILayout.Label($"Bound: {_rewardListenerBound}   Count: {_endSeasonRewardReqCount}");
                if (GUILayout.Button("Clear", GUILayout.Width(80)))
                {
                    _endSeasonRewardReqCount = 0;
                    _hasLastEndSeasonRewardReq = false;
                    _lastEndSeasonRewardRealtime = 0f;
                }
                GUILayout.EndHorizontal();

                if (_hasLastEndSeasonRewardReq)
                {
                    float dt = Time.realtimeSinceStartup - _lastEndSeasonRewardRealtime;
                    GUILayout.Label($"Last: Season={_lastEndSeasonRewardReq.Season}  Year={_lastEndSeasonRewardReq.YearIndex}  Day={_lastEndSeasonRewardReq.DayIndex}   ({dt:0.00}s ago)");
                }
                else
                {
                    GUILayout.Label("Last: (none yet)");
                }

                GUILayout.Space(6);
            }

            // ---- Day41: Tutorial Hints ----
            if (_homeShowHints)
            {
                GUILayout.Space(10);
                GUILayout.Label("Day41: Tutorial Hints");

                if (_gs == null || _gs.TutorialHints == null)
                {
                    GUILayout.Label("TutorialHintsService: missing");
                }
                else
                {
                    var h = _gs.TutorialHints;
                    GUILayout.Label($"ActiveWindow: 10min | RunAge(sim): {h.RunAge:0.0}s");
                    GUILayout.Label($"Counts: UnassignedNPC={h.HintNpcUnassignedCount} | ProducerFull={h.HintProducerFullCount} | OutOfAmmo={h.HintOutOfAmmoCount} | WaveIncoming={h.HintWaveIncomingCount}");
                    GUILayout.Label($"LastHintRealtime: {h.LastHintRealtime:0.00}s (Time.realtimeSinceStartup)");
                }

                GUILayout.Space(6);
            }

            // ---- RunClock HUD ----
            if (_homeShowRunClock)
            {
                GUILayout.Space(10);
                if (_runClockHud != null)
                    _runClockHud.DrawHubGUI();
                else
                    GUILayout.Label("DebugRunClockHUD: missing (add component to scene if you want clock controls)");

                GUILayout.Space(6);
            }

            // ---- Lane HUD ----
            if (_homeShowLanes)
            {
                GUILayout.Space(10);
                if (_combatLaneHud != null)
                    _combatLaneHud.DrawHubGUI();
                else
                    GUILayout.Label("DebugCombatLaneHUD: missing (add component to scene if you want lane spawn debug)");

                GUILayout.Space(6);
            }

            // ---- Save/Load HUD ----
            if (_homeShowSaveLoad)
            {
                GUILayout.Space(10);
                if (_gs != null) _saveLoadHUD.Draw(_gs);
                else GUILayout.Label("SaveLoadHUD: GameServices is null");

                GUILayout.Space(6);
            }

            // ---- Day34: Wave HUD ----
            if (_homeShowWave)
            {
                GUILayout.Space(10);
                if (_waveHud != null)
                    _waveHud.DrawHubGUI();
                else
                    GUILayout.Label("DebugWaveHUD: missing (add component to scene if you want wave counters)");

                GUILayout.Space(6);
            }

            GUILayout.EndScrollView();
        }
    }
}